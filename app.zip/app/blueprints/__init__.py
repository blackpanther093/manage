"""
Blueprints package for ManageIt application
"""
