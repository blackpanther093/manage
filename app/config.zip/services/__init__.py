"""
Services package for ManageIt application
"""
