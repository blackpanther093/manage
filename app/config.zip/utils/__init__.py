"""
Utilities package for ManageIt application
"""
